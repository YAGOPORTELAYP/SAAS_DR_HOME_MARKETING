import { ArrowSmUpIcon, ArrowSmDownIcon } from '@heroicons/react/solid';

interface MetricsCardProps {
  title: string;
  value: string;
  trend: 'up' | 'down';
  change: string;
}

export function MetricsCard({ title, value, trend, change }: MetricsCardProps) {
  return (
    <div className="bg-white overflow-hidden shadow rounded-lg">
      <div className="p-5">
        <div className="flex items-center">
          <div className="flex-1">
            <p className="text-sm font-medium text-gray-500 truncate">
              {title}
            </p>
            <p className="mt-1 text-3xl font-semibold text-gray-900">
              {value}
            </p>
          </div>
          <div className={`flex items-center ${
            trend === 'up' ? 'text-green-600' : 'text-red-600'
          }`}>
            {trend === 'up' ? (
              <ArrowSmUpIcon className="h-5 w-5" />
            ) : (
              <ArrowSmDownIcon className="h-5 w-5" />
            )}
            <span className="text-sm font-medium ml-1">
              {change}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
} 