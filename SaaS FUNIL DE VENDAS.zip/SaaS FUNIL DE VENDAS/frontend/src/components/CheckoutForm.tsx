import { useState } from 'react';
import { useRouter } from 'next/router';

interface CheckoutFormProps {
  planType: string;
  amount: number;
}

export function CheckoutForm({ planType, amount }: CheckoutFormProps) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async () => {
    try {
      setLoading(true);
      
      const response = await fetch('/api/payments/create-subscription', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          plan_type: planType,
          amount: amount,
        }),
      });

      const data = await response.json();
      
      // Redirecionar para página de pagamento do Mercado Pago
      window.location.href = data.init_point;
    } catch (error) {
      console.error('Erro ao processar pagamento:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 border rounded-lg shadow-sm">
      <h2 className="text-xl font-bold mb-4">Plano {planType}</h2>
      <p className="text-gray-600 mb-4">R$ {amount.toFixed(2)}/mês</p>
      
      <button
        onClick={handleSubscribe}
        disabled={loading}
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 disabled:opacity-50"
      >
        {loading ? 'Processando...' : 'Assinar Agora'}
      </button>
    </div>
  );
} 