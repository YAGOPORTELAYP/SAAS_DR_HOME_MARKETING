import { useRouter } from 'next/router';
import Link from 'next/link';
import {
  ChartPieIcon,
  CurrencyDollarIcon,
  UserGroupIcon,
  PresentationChartLineIcon,
  DocumentReportIcon,
} from '@heroicons/react/outline';

export function Sidebar() {
  const router = useRouter();

  const menuItems = [
    {
      name: 'Analytics',
      href: '/analytics',
      icon: ChartPieIcon,
    },
    {
      name: 'Campanhas',
      href: '/campaigns',
      icon: PresentationChartLineIcon,
      subItems: [
        { name: 'Facebook Ads', href: '/campaigns/facebook' },
        { name: 'Google Ads', href: '/campaigns/google' },
        { name: 'TikTok Ads', href: '/campaigns/tiktok' },
      ],
    },
    {
      name: 'Financeiro',
      href: '/finance',
      icon: CurrencyDollarIcon,
    },
    {
      name: 'Relatórios',
      href: '/reports',
      icon: DocumentReportIcon,
    },
    {
      name: 'Equipe',
      href: '/team',
      icon: UserGroupIcon,
    },
  ];

  const isActive = (path: string) => router.pathname === path;

  return (
    <div className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 lg:border-r lg:border-gray-200 lg:bg-white lg:pt-16">
      <div className="flex-1 flex flex-col overflow-y-auto">
        <nav className="flex-1 px-2 py-4 space-y-1">
          {menuItems.map((item) => (
            <div key={item.name}>
              <Link
                href={item.href}
                className={`group flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                  isActive(item.href)
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <item.icon className="mr-3 h-5 w-5" />
                {item.name}
              </Link>

              {item.subItems && (
                <div className="ml-8 mt-1 space-y-1">
                  {item.subItems.map((subItem) => (
                    <Link
                      key={subItem.name}
                      href={subItem.href}
                      className={`group flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                        isActive(subItem.href)
                          ? 'bg-blue-50 text-blue-700'
                          : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      {subItem.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>
      </div>
    </div>
  );
} 