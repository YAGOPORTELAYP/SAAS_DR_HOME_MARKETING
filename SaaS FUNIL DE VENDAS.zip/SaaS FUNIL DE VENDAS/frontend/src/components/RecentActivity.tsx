import { useEffect, useState } from 'react';
import { 
  CheckCircleIcon, 
  ExclamationIcon,
  InformationCircleIcon
} from '@heroicons/react/solid';

interface Activity {
  id: number;
  type: 'success' | 'warning' | 'info';
  message: string;
  timestamp: string;
}

export function RecentActivity() {
  const [activities, setActivities] = useState<Activity[]>([
    {
      id: 1,
      type: 'success',
      message: 'Campanha "Black Friday" atingiu meta de ROAS',
      timestamp: '2 min atrás'
    },
    {
      id: 2,
      type: 'warning',
      message: 'Orçamento diário atingido em "Google Search"',
      timestamp: '15 min atrás'
    },
    {
      id: 3,
      type: 'info',
      message: 'Nova campanha criada: "Remarketing - Abandono"',
      timestamp: '1 hora atrás'
    },
    // Adicione mais atividades de exemplo aqui
  ]);

  const getIcon = (type: Activity['type']) => {
    switch (type) {
      case 'success':
        return <CheckCircleIcon className="h-5 w-5 text-green-500" />;
      case 'warning':
        return <ExclamationIcon className="h-5 w-5 text-yellow-500" />;
      case 'info':
        return <InformationCircleIcon className="h-5 w-5 text-blue-500" />;
    }
  };

  return (
    <div className="flow-root">
      <ul className="-mb-8">
        {activities.map((activity, index) => (
          <li key={activity.id}>
            <div className="relative pb-8">
              {index !== activities.length - 1 && (
                <span
                  className="absolute top-5 left-5 -ml-px h-full w-0.5 bg-gray-200"
                  aria-hidden="true"
                />
              )}
              <div className="relative flex items-start space-x-3">
                <div className="relative">
                  {getIcon(activity.type)}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm text-gray-500">
                    <p className="font-medium text-gray-900 mb-0.5">
                      {activity.message}
                    </p>
                    <p className="text-xs text-gray-400">
                      {activity.timestamp}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
} 