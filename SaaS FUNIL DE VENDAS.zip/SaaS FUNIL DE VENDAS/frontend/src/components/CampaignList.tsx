import { useState, useEffect } from 'react';
import { 
  ChartBarIcon, 
  CurrencyDollarIcon, 
  StatusOnlineIcon 
} from '@heroicons/react/outline';

interface Campaign {
  id: number;
  name: string;
  platform: string;
  status: string;
  budget: number;
  spent: number;
  conversions: number;
  roas: number;
}

export function CampaignList() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([
    {
      id: 1,
      name: "Black Friday - Conversão",
      platform: "Facebook",
      status: "active",
      budget: 5000,
      spent: 2345.67,
      conversions: 42,
      roas: 2.8
    },
    {
      id: 2,
      name: "Google Search - Marca",
      platform: "Google",
      status: "active",
      budget: 3000,
      spent: 1234.56,
      conversions: 28,
      roas: 3.2
    },
    // Adicione mais campanhas de exemplo aqui
  ]);

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Campanha
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Status
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Orçamento
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Conversões
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              ROAS
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {campaigns.map((campaign) => (
            <tr key={campaign.id} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="flex-shrink-0 h-10 w-10 flex items-center justify-center rounded-lg bg-blue-100 text-blue-600">
                    <ChartBarIcon className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <div className="text-sm font-medium text-gray-900">
                      {campaign.name}
                    </div>
                    <div className="text-sm text-gray-500">
                      {campaign.platform}
                    </div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                  campaign.status === 'active' 
                    ? 'bg-green-100 text-green-800'
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {campaign.status === 'active' ? 'Ativo' : 'Pausado'}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">
                  R$ {campaign.budget.toLocaleString('pt-BR')}
                </div>
                <div className="text-sm text-gray-500">
                  Gasto: R$ {campaign.spent.toLocaleString('pt-BR')}
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {campaign.conversions}
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm font-medium text-gray-900">
                  {campaign.roas.toFixed(1)}x
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
} 