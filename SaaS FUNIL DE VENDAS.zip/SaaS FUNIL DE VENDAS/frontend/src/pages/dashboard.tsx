import { MetricsCard } from '../components/MetricsCard'
import { CampaignList } from '../components/CampaignList'
import { RecentActivity } from '../components/RecentActivity'

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        
        <div className="flex space-x-3">
          <button className="px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">
            Exportar
          </button>
          <button className="px-4 py-2 bg-blue-600 border border-transparent rounded-md shadow-sm text-sm font-medium text-white hover:bg-blue-700">
            Nova Campanha
          </button>
        </div>
      </div>

      {/* Métricas */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <MetricsCard
          title="ROI Total"
          value="235%"
          trend="up"
          change="12.5%"
        />
        <MetricsCard
          title="Investimento"
          value="R$ 15.000"
          trend="up"
          change="8.2%"
        />
        <MetricsCard
          title="Conversões"
          value="127"
          trend="down"
          change="3.1%"
        />
        <MetricsCard
          title="CPA Médio"
          value="R$ 42,50"
          trend="down"
          change="5.4%"
        />
      </div>

      {/* Conteúdo Principal */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Campanhas Ativas */}
        <div className="lg:col-span-2">
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">
              Campanhas Ativas
            </h2>
            <CampaignList />
          </div>
        </div>

        {/* Atividade Recente */}
        <div className="lg:col-span-1">
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">
              Atividade Recente
            </h2>
            <RecentActivity />
          </div>
        </div>
      </div>
    </div>
  )
} 