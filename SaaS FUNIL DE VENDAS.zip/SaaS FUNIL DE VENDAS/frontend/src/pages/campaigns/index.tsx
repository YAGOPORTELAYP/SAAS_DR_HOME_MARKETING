import { useState } from 'react';
import { PlusIcon, FilterIcon, SearchIcon } from '@heroicons/react/outline';
import { CampaignList } from '../../components/CampaignList';

export default function Campaigns() {
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <div className="space-y-6">
      <div className="sm:flex sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Campanhas</h1>
        <div className="mt-4 sm:mt-0">
          <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700">
            <PlusIcon className="h-5 w-5 mr-2" />
            Nova Campanha
          </button>
        </div>
      </div>

      <div className="bg-white shadow rounded-lg">
        {/* Filtros e Busca */}
        <div className="p-6 border-b border-gray-200">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <SearchIcon className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                placeholder="Buscar campanhas..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div>
              <button className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                <FilterIcon className="h-5 w-5 mr-2 text-gray-500" />
                Filtros
              </button>
            </div>
          </div>
        </div>

        {/* Lista de Campanhas */}
        <div className="p-6">
          <CampaignList />
        </div>
      </div>
    </div>
  );
} 