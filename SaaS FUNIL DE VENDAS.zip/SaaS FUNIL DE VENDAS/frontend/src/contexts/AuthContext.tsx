import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useRouter } from 'next/router';
import { api } from '../services/api';
import { GoogleOAuthProvider } from '@react-oauth/google';

interface User {
  id: number;
  name: string;
  email: string;
  role: string;
}

interface AuthContextData {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (data: SignUpData) => Promise<void>;
  signOut: () => void;
  forgotPassword: (email: string) => Promise<void>;
  resetPassword: (token: string, password: string) => Promise<void>;
  signInWithGoogle: (credential: string) => Promise<void>;
  signInWithFacebook: (accessToken: string) => Promise<void>;
}

interface SignUpData {
  name: string;
  email: string;
  password: string;
}

const AuthContext = createContext({} as AuthContextData);

export function AuthProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUserFromStorage();
  }, []);

  async function loadUserFromStorage() {
    try {
      const token = localStorage.getItem('@MarketingSaaS:token');
      
      if (token) {
        api.defaults.headers.authorization = `Bearer ${token}`;
        const response = await api.get('/users/me');
        setUser(response.data);
      }
    } catch (error) {
      console.error('Erro ao carregar usuário:', error);
    } finally {
      setLoading(false);
    }
  }

  async function signIn(email: string, password: string) {
    try {
      const response = await api.post('/auth/login', {
        email,
        password,
      });

      const { token, user } = response.data;

      localStorage.setItem('@MarketingSaaS:token', token);
      api.defaults.headers.authorization = `Bearer ${token}`;

      setUser(user);
      router.push('/dashboard');
    } catch (error: any) {
      throw new Error(error.response?.data?.message || 'Erro ao fazer login');
    }
  }

  async function signUp(data: SignUpData) {
    try {
      const response = await api.post('/auth/register', data);
      const { token, user } = response.data;

      localStorage.setItem('@MarketingSaaS:token', token);
      api.defaults.headers.authorization = `Bearer ${token}`;

      setUser(user);
      router.push('/dashboard');
    } catch (error: any) {
      throw new Error(error.response?.data?.message || 'Erro ao criar conta');
    }
  }

  function signOut() {
    localStorage.removeItem('@MarketingSaaS:token');
    setUser(null);
    router.push('/login');
  }

  async function forgotPassword(email: string) {
    try {
      await api.post('/auth/forgot-password', { email });
    } catch (error: any) {
      throw new Error(error.response?.data?.message || 'Erro ao enviar email');
    }
  }

  async function resetPassword(token: string, password: string) {
    try {
      await api.post('/auth/reset-password', { token, password });
    } catch (error: any) {
      throw new Error(error.response?.data?.message || 'Erro ao redefinir senha');
    }
  }

  async function signInWithGoogle(credential: string) {
    try {
      const response = await api.post('/auth/google', { credential });
      const { token, user } = response.data;

      localStorage.setItem('@MarketingSaaS:token', token);
      api.defaults.headers.authorization = `Bearer ${token}`;

      setUser(user);
      router.push('/dashboard');
    } catch (error: any) {
      throw new Error(error.response?.data?.message || 'Erro ao fazer login com Google');
    }
  }

  async function signInWithFacebook(accessToken: string) {
    try {
      const response = await api.post('/auth/facebook', { accessToken });
      const { token, user } = response.data;

      localStorage.setItem('@MarketingSaaS:token', token);
      api.defaults.headers.authorization = `Bearer ${token}`;

      setUser(user);
      router.push('/dashboard');
    } catch (error: any) {
      throw new Error(error.response?.data?.message || 'Erro ao fazer login com Facebook');
    }
  }

  return (
    <GoogleOAuthProvider clientId={process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID!}>
      <AuthContext.Provider
        value={{
          user,
          isAuthenticated: !!user,
          loading,
          signIn,
          signUp,
          signOut,
          forgotPassword,
          resetPassword,
          signInWithGoogle,
          signInWithFacebook,
        }}
      >
        {children}
      </AuthContext.Provider>
    </GoogleOAuthProvider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
} 