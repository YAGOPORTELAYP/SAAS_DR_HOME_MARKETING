from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "Marketing SaaS"
    DATABASE_URL: str
    REDIS_URL: str
    JWT_SECRET: str
    FACEBOOK_API_KEY: str
    GOOGLE_ADS_API_KEY: str
    ALLOWED_ORIGINS: list[str] = ["http://localhost:3000"]
    
    # Mercado Pago
    MERCADOPAGO_ACCESS_TOKEN: str
    MERCADOPAGO_PUBLIC_KEY: str
    FRONTEND_URL: str = "http://localhost:3000"

    class Config:
        env_file = ".env"

settings = Settings() 