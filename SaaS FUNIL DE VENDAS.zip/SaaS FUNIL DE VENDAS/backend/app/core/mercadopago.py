import mercadopago
from app.core.config import settings

class MercadoPagoClient:
    def __init__(self):
        self.sdk = mercadopago.SDK(settings.MERCADOPAGO_ACCESS_TOKEN)

    def create_preference(self, subscription_data):
        preference_data = {
            "items": [
                {
                    "title": f"Assinatura {subscription_data['plan_type']}",
                    "quantity": 1,
                    "currency_id": "BRL",
                    "unit_price": float(subscription_data['amount'])
                }
            ],
            "back_urls": {
                "success": f"{settings.FRONTEND_URL}/payment/success",
                "failure": f"{settings.FRONTEND_URL}/payment/failure",
                "pending": f"{settings.FRONTEND_URL}/payment/pending"
            },
            "auto_return": "approved",
            "external_reference": str(subscription_data['id'])
        }
        
        result = self.sdk.preference().create(preference_data)
        return result["response"]

    def process_webhook(self, data):
        if data["type"] == "payment":
            payment_info = self.sdk.payment().get(data["data"]["id"])
            return payment_info["response"]
        return None 