from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.api import deps
from app.schemas.campaign import Campaign, CampaignCreate
from app.crud import campaign

router = APIRouter()

@router.get("/", response_model=List[Campaign])
def list_campaigns(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100
):
    """
    Recupera lista de campanhas.
    """
    campaigns = campaign.get_multi(db, skip=skip, limit=limit)
    return campaigns

@router.post("/", response_model=Campaign)
def create_campaign(
    *,
    db: Session = Depends(deps.get_db),
    campaign_in: CampaignCreate
):
    """
    Cria nova campanha.
    """
    campaign = campaign.create(db, obj_in=campaign_in)
    return campaign 