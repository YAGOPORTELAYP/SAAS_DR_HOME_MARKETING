from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from typing import Any
from app.api import deps
from app.core.mercadopago import MercadoPagoClient
from app.crud import subscription, payment
from app.schemas.payment import PaymentCreate, Payment
from app.schemas.subscription import SubscriptionCreate

router = APIRouter()
mp_client = MercadoPagoClient()

@router.post("/create-subscription", response_model=Any)
def create_subscription(
    *,
    db: Session = Depends(deps.get_db),
    subscription_data: SubscriptionCreate,
    current_user = Depends(deps.get_current_user)
):
    """
    Cria uma nova assinatura e retorna o link de pagamento
    """
    # Criar assinatura no banco
    sub = subscription.create(
        db,
        obj_in=subscription_data,
        user_id=current_user.id
    )
    
    # Criar preferência no Mercado Pago
    preference = mp_client.create_preference({
        "id": sub.id,
        "plan_type": sub.plan_type,
        "amount": sub.amount
    })
    
    return {
        "subscription_id": sub.id,
        "init_point": preference["init_point"]
    }

@router.post("/webhook")
async def payment_webhook(
    data: dict = Body(...),
    db: Session = Depends(deps.get_db)
):
    """
    Webhook para processar notificações do Mercado Pago
    """
    payment_info = mp_client.process_webhook(data)
    
    if payment_info:
        # Atualizar status do pagamento
        payment_data = PaymentCreate(
            subscription_id=payment_info["external_reference"],
            amount=payment_info["transaction_amount"],
            status=payment_info["status"],
            payment_method=payment_info["payment_method_id"],
            external_id=str(payment_info["id"]),
            metadata=payment_info
        )
        
        new_payment = payment.create(db, obj_in=payment_data)
        
        # Atualizar status da assinatura
        if payment_info["status"] == "approved":
            subscription.update_status(
                db,
                id=payment_info["external_reference"],
                status="active"
            )
    
    return {"status": "success"} 