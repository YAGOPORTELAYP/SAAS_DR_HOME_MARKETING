from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
from app.db.base_class import Base

class Payment(Base):
    __tablename__ = "payments"

    id = Column(Integer, primary_key=True, index=True)
    subscription_id = Column(Integer, ForeignKey("subscriptions.id"))
    amount = Column(Float)
    currency = Column(String, default="BRL")
    status = Column(String)
    payment_method = Column(String)
    external_id = Column(String)  # ID do Mercado Pago
    created_at = Column(DateTime, default=datetime.utcnow)
    metadata = Column(JSON)

    subscription = relationship("Subscription", back_populates="payments") 