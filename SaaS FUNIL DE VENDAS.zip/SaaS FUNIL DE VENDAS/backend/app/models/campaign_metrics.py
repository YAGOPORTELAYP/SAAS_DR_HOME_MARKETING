from sqlalchemy import Column, Integer, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.db.base_class import Base

class CampaignMetrics(Base):
    __tablename__ = "campaign_metrics"

    id = Column(Integer, primary_key=True, index=True)
    campaign_id = Column(Integer, ForeignKey("campaigns.id"))
    impressions = Column(Integer)
    clicks = Column(Integer)
    spend = Column(Float)
    conversions = Column(Integer)
    revenue = Column(Float)
    date = Column(DateTime)

    campaign = relationship("Campaign", back_populates="metrics") 