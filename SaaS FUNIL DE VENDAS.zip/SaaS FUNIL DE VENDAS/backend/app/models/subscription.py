from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Enum
from sqlalchemy.orm import relationship
from datetime import datetime
from app.db.base_class import Base
import enum

class SubscriptionStatus(str, enum.Enum):
    ACTIVE = "active"
    CANCELLED = "cancelled"
    PENDING = "pending"
    FAILED = "failed"

class Subscription(Base):
    __tablename__ = "subscriptions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    plan_type = Column(String)
    status = Column(String, default=SubscriptionStatus.PENDING)
    amount = Column(Float)
    currency = Column(String, default="BRL")
    created_at = Column(DateTime, default=datetime.utcnow)
    next_billing_date = Column(DateTime)
    payment_method = Column(String)
    external_id = Column(String)  # ID do Mercado Pago

    user = relationship("User", back_populates="subscriptions")
    payments = relationship("Payment", back_populates="subscription") 